/*
 *   IRC - Internet Relay Chat, src/modules/m_codepage.c
 *   (C) 1999-2001 Carsten Munk (Techie/Stskeeps) <stskeeps@tspre.org>
 *
 *   See file AUTHORS in IRC package for additional names of
 *   the programmers. 
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include "config.h"
#include "struct.h"
#include "common.h"
#include "sys.h"
#include "numeric.h"
#include "msg.h"
#include "channel.h"
#include <time.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <io.h>
#endif
#include <fcntl.h>
#include "h.h"
#include "proto.h"
#ifdef STRIPBADWORDS
#include "badwords.h"
#endif
#ifdef _WIN32
#include "version.h"
#endif

DLLFUNC int m_codepage(aClient *cptr, aClient *sptr, int parc, char *parv[]);
DLLFUNC int m_codepages(aClient *cptr, aClient *sptr, int parc, char *parv[]);

ModuleHeader MOD_HEADER(m_codepage)
	= {
	"codepage",    /* Name of module */
	"$Id: m_codepage.c,v 1.1.0.0 2002/12/29 14:20:45 i (admin@i386.net.ru) & Spider Exp $", /* Version */
	"/codepage", /* Short description of module */
	"3.2-b8-1",
	};

/*
 * The purpose of these ifdefs, are that we can "static" link the ircd if we
 * want to
*/


DLLFUNC int    MOD_INIT(m_codepage)(ModuleInfo *modinfo)
{
	add_Command(MSG_CODEPAGE, TOK_CODEPAGE, m_codepage, MAXPARA);
	add_Command(MSG_CODEPAGES, TOK_CODEPAGES, m_codepages, MAXPARA);
	return MOD_SUCCESS;
    
}

DLLFUNC int    MOD_LOAD(m_codepage)(int module_load)
{
	return MOD_SUCCESS;
}

DLLFUNC int    MOD_UNLOAD(m_codepage)(int module_unload)
{
	if (del_Command(MSG_CODEPAGE, TOK_CODEPAGE, m_codepage) < 0)
	{
		sendto_realops("Failed to delete commands when unloading %s",
			MOD_HEADER(m_codepage).name);
	}
	return MOD_SUCCESS;
}

/* 
 * m_codepage - 12/29/2002 - ECTb
 * :prefix CODEPAGE <new codepage>
 * parv[0] - sender
 * parv[1] - codepage
 *
*/

DLLFUNC int m_codepage(aClient *cptr, aClient *sptr, int parc, char *parv[])
{
	if (!MyClient(sptr)) 
	{
		aClient *acptr;
#ifndef WITH_ICONV
	if (MyClient(sptr))
	{
		sendto_one(sptr, ":%s NOTICE %s :*** The /codepage command is disabled on this server", 
				me.name, sptr->name);
		return 0;
	}
#else
	if (parc < 3)
		return 0;    
	acptr = find_person(parv[1], (aClient *)NULL);
		if (!acptr)
			return 0;
	if (Find_codepage(parv[2])) 
	{
		if (!acptr->codepage)
			acptr->codepage=strdup(parv[2]);
		else
			strcpy(acptr->codepage, parv[2]);
	}
#endif
	return 0;
	}

#ifdef WITH_ICONV
	
	if (parc < 2)
	{
	sendto_one(sptr,
		":%s NOTICE %s :*** /codepage syntax is /codepage <new_codepage>",
			me.name, sptr->name);
	sendto_one(sptr,
		":%s NOTICE %s :*** Your current codepage is: %s Port: %d",
			me.name, sptr->name, sptr->codepage, cptr->listener->port);
		return 0;
	}

	if (strlen(parv[1]) < 1)
	{
	sendto_one(sptr,
		":%s NOTICE %s :*** Write atleast something to change the codepage to!",
			me.name, sptr->name);
		return 0;
	}

	if (strlen(parv[1]) > 16)
	{
		sendto_one(sptr,
			":%s NOTICE %s :*** Codepage Error: Too long codepage!!",
				me.name, sptr->name);
		return 0;
	}

	if (Find_codepage(parv[1]))
	{
		sptr->codepage = strdup(parv[1]);
		sendto_one(sptr, rpl_str(RPL_CODEPAGE), me.name, parv[0], sptr->codepage);
		sendto_serv_butone_token(cptr, sptr->name,
			MSG_CODEPAGE, TOK_CODEPAGE, "%s :%s", sptr->name, sptr->codepage);
	return 0;
	}
	else
	{
		sendto_one(sptr,
			":%s NOTICE %s :*** /Codepage Error: Unknown codepage %s",
				me.name, parv[0], parv[1]);
		return 0;
	}
#endif
	return 0;

}


/* 
 * m_codepages - 2/09/2003 - ECTb
 * :prefix CODEPAGES
 * parv[0] - sender
 *
*/

DLLFUNC int m_codepages(aClient *cptr, aClient *sptr, int parc, char *parv[])
{
#ifdef WITH_ICONV
	ConfigItem_codepage *cpage = NULL;
	for (cpage = conf_codepage; cpage; cpage = (ConfigItem_codepage *)cpage->next) 
	{
		sendto_one(sptr, rpl_str(RPL_CODEPAGES), me.name, 
			parv[0], cpage->name, cpage->defcpage?" default":"");
	}
	sendto_one(sptr, rpl_str(RPL_ENDOFCODEPAGES), me.name, parv[0]);
#else
	sendto_one(sptr, ":%s NOTICE %s :*** The /codepages command is disabled on this server", 
				me.name, sptr->name);
#endif
	return 0;
}
